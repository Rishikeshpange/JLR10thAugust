//
//  ActivitySearchViewController.h
//  NEEV
//
//  Created by Sachin Sharma on 27/03/15.
//  Copyright (c) 2015 LetsIDev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ActivitySearchViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *textSearch;
@property (weak, nonatomic) IBOutlet UITextField *textDate;
@property (weak, nonatomic) IBOutlet UITextField *textactivitytype;
@property (weak, nonatomic) IBOutlet UITextField *textstatus;
@property (weak, nonatomic) IBOutlet UITextField *textdse;
@property (weak, nonatomic) IBOutlet UITextField *texttaluka;
@property (weak, nonatomic) IBOutlet UITextField *textppl;

@end
