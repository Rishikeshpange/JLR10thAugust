//
//  INFOViewController.h
//  DSE
//
//  Created by Rishikesh on 07/07/15.
//  Copyright (c) 2015 LetsIDev. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GlobalDetails.h"

@interface INFOViewController : UIViewController
{
    GlobalDetails *userDetailsVal_;

}

@end
