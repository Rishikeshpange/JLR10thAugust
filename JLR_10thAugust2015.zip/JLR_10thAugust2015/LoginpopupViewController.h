//
//  LoginpopupViewController.h
//  NEEV
//
//  Created by Nihal Shaikh on 7/27/15.
//  Copyright (c) 2015 LetsIDev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginpopupViewController : UIViewController

@end
