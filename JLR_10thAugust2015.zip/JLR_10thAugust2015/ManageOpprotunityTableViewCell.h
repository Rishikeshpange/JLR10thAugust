//
//  ManageOpprotunityTableViewCell.h
//  NEEV
//
//  Created by Sachin Sharma on 11/07/15.
//  Copyright (c) 2015 LetsIDev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ManageOpprotunityTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lbl_LeadId;

@property (weak, nonatomic) IBOutlet UILabel *lbl_LeadIdResult;


@property (weak, nonatomic) IBOutlet UILabel *lbl_LeadCreationDate;

@property (weak, nonatomic) IBOutlet UILabel *lbl_LeadCreationDateResult;

@property (weak, nonatomic) IBOutlet UILabel *lbl_ProductName;
@property (weak, nonatomic) IBOutlet UILabel *lbl_Product_NameResult;




@end
