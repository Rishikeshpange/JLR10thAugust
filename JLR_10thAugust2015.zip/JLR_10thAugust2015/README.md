MultipleDetailViewsUsingStoryboards
===================================

Simple Example using Storyboards to change Detailviews 
over selecting a specific tableview-cell
