//
//  UserDetails.m
//  NEEV
//
//  Created by Gurneha Naggi on 7/14/15.
//  Copyright (c) 2015 LetsIDev. All rights reserved.
//

#import "UserDetails.h"

@implementation UserDetails

UserDetails *user;

@end
