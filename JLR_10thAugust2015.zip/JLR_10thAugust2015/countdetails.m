//
//  countdetails.m
//  NEEV
//
//  Created by Nihal Shaikh on 7/30/15.
//  Copyright (c) 2015 LetsIDev. All rights reserved.
//

#import "countdetails.h"

countdetails *count,*searchOpportunity_list;
NSMutableArray *activityIdarray;


@implementation countdetails


@synthesize _ActivityId,_ActivityUID;


@end
