//
//  positionlist.h
//  NEEV
//
//  Created by Gurneha Naggi on 7/14/15.
//  Copyright (c) 2015 LetsIDev. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSMutableArray *analyticslistarray;


@interface positionlist : NSObject


//@property(nonatomic,strong)NSString* positionName;

//@property(nonatomic,strong)NSString* positionId;


@property(nonatomic,strong)NSMutableArray *positionId;

@property(nonatomic,strong)NSMutableArray *positionName;





@end


extern positionlist *Position1;
