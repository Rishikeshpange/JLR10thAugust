//
//  Dashboard_Leads_tablecell_VC.h
//  test
//
//  Created by Admin on 09/03/15.
//  Copyright (c) 2015 LetsIDev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Dashboard_Leads_tablecell_VC : UITableViewCell
{
    
}

@property (weak, nonatomic) IBOutlet UILabel *lbl_leadName;
@property (weak, nonatomic) IBOutlet UILabel *lbl_leadSummary;


@end
