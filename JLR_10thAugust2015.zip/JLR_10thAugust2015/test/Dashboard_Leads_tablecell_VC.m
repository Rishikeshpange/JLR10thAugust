//
//  Dashboard_Leads_tablecell_VC.m
//  test
//
//  Created by Admin on 09/03/15.
//  Copyright (c) 2015 LetsIDev. All rights reserved.
//

#import "Dashboard_Leads_tablecell_VC.h"

@implementation Dashboard_Leads_tablecell_VC
@synthesize lbl_leadName,lbl_leadSummary;

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
