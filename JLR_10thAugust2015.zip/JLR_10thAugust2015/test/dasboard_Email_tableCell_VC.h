//
//  dasboard_Email_tableCell_VC.h
//  test
//
//  Created by Admin on 05/03/15.
//  Copyright (c) 2015 LetsIDev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface dasboard_Email_tableCell_VC : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *lbl_activityid;
@property (weak, nonatomic) IBOutlet UILabel *lbl_activityType;
@property (weak, nonatomic) IBOutlet UILabel *lbl_activityidresult;
@property (weak, nonatomic) IBOutlet UILabel *lbl_activitytyperesult;




@end
